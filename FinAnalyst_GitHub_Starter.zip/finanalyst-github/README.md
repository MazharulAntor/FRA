# FinAnalyst - ICT803 Group 24

English-language React frontend prototype for an AI-powered financial analyst.
Frontend / dashboard contributor: Yunus Sahbenderoglu (59411).

## Current status

This is a working **frontend demo**, not a completed financial analysis system.
It preserves the approved three-panel prototype: Documents, Chat, and Charts & Results.

- Local PDF selection and document list (PDF extension and 50 MB size checks).
- Chat with predefined, simulated replies and sample source tags.
- Revenue and margin charts using Recharts; KPI tiles and five-year summary.
- Responsive layout and English UI.
- All figures, document references and citations are fictional sample data.
- PDFs are **not uploaded, parsed, indexed or analysed**. Page refresh resets state.
- There is no FastAPI, RAG, vector database, LLM integration or authentication here.
- No API keys or credentials are included or required to run the demo.

## Run locally

Install Node.js **22.13 or later** and npm. Extract the archive and open a terminal
in the folder containing `package.json`.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite. Do not run `npm ci` until a package-lock.json
has been generated and committed by the team.

```bash
npm run typecheck
npm run build
npm run preview
```

The build creates `dist/`. Keep `node_modules/` and `dist/` out of Git.
The exact direct dependency versions are pinned; commit the generated npm lockfile
after the first install so the team also shares transitive dependency versions.

## Project files

| Path | Purpose |
| --- | --- |
| `src/App.tsx` | Main screen, sample dataset, document selection and simulated chat |
| `src/index.css` | Dark theme, three-column layout and mobile styles |
| `src/components/ui/tabs.tsx` | Accessible revenue / margin tabs |
| `src/components/ui/table.tsx` | Financial summary table components |
| `src/lib/utils.ts` | CSS class utilities |
| `src/main.tsx` | React entry point |
| `vite.config.ts` | Vite configuration and `@/` source alias |
| `vendor/` | Existing UI animation stylesheet |

## Backend integration - next phase

Coordinate the API contract with the backend developer before implementation.
Part C describes these intended endpoints; **they are not implemented here**:

1. `POST /api/upload`: send a PDF as multipart/form-data; store the returned
   `doc_id` and show upload / parsing / indexing status from the real response.
2. `POST /api/query`: send `question`, `doc_id` and `session_id`; include
   `prev_query_id` for a follow-up question.
3. Replace the `setTimeout` mock inside `submit()` with the real API call.
4. Replace hardcoded chart data, KPI values and citation labels with the response.
5. Agree response field names, error schemas, session ownership, CORS and timeout
   behaviour with the backend team. Test unsupported PDFs and no-evidence replies.

Keep LLM keys on the backend. Never place them in React code or a `VITE_` variable,
because frontend environment variables are visible to browser users.

The sample document does not contain a real PDF. Do not present demo citations as
verified evidence. Clear or replace sample results when integrating real documents.

## Team workflow

- Create a feature branch for each task, such as `feature/pdf-upload-api`.
- Commit small, meaningful changes under your own identity.
- Open a pull request and request review before merging into the main branch.
- Keep `main` runnable; run typecheck and build before submitting a pull request.
- Document AI assistance and your own work honestly in your reflective journal.

## Initial GitHub upload

Create an empty repository, then upload the **contents** of this folder, including
`src`, `public`, `vendor` and the configuration files. Do not upload only the ZIP.
For command-line upload, replace the URL below with your team's repository:

```bash
git init
git add .
git commit -m "Add FinAnalyst frontend prototype"
git branch -M main
git remote add origin https://github.com/YOUR-TEAM/YOUR-REPOSITORY.git
git push -u origin main
```

Do not run `git init` if the team repository has already been cloned. Copy these
files into its agreed frontend directory and follow the team's branch workflow.

This portable package does not depend on ChatGPT Sites or its hosting configuration.
